package at.htl.examples;

public class Prisma {
    public static void main(String[] args) {
        System.out.println("=================");
        System.out.println("║ Hello, World! ║");
        System.out.println("=================");
    }
}
